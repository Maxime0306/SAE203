// Contenu de programme.sh (à remplir selon le rôle du fichier)
